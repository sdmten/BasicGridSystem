/*   1:    */ package game1;
/*   2:    */ 
/*   3:    */ import game1.hsa.Console;
/*   4:    */ import game1.lib.ErrorMessage;
/*   5:    */ import game1.lib.SpriteImport;
/*   6:    */ import java.awt.Color;
/*   7:    */ import java.awt.Image;
/*   8:    */ import java.awt.image.BufferedImage;
/*   9:    */ import java.io.BufferedReader;
/*  10:    */ import java.io.IOException;
/*  11:    */ import java.io.InputStream;
/*  12:    */ import java.io.InputStreamReader;
/*  13:    */ import java.io.PrintStream;
/*  14:    */ import java.util.Random;
/*  15:    */ import java.util.StringTokenizer;
/*  16:    */ import javax.imageio.ImageIO;
/*  17:    */ 
/*  18:    */ public class BasicGridSystem
/*  19:    */ {
/*  20: 30 */   static Console c = new Console("GameWindow - By Squishy Enterprises");
/*  21: 32 */   static SpriteImport spriteImport = new SpriteImport();
/*  22:    */   static BufferedImage tile;
/*  23:    */   static BufferedImage map;
/*  24: 36 */   static String mapNameImage = "/game1/map2.jpg";
/*  25: 37 */   static String mapNameText = "/game1/Testmap2.txt";
/*  26:    */   static int x1;
/*  27:    */   static int y1;
/*  28: 42 */   static int x2 = 0;
/*  29: 43 */   static int y2 = 0;
/*  30:    */   static int u;
/*  31:    */   static int v;
/*  32:    */   static char ch;
/*  33:    */   static char ch2;
/*  34:    */   static Runnable r;
/*  35: 50 */   static String direction = "s";
/*  36: 51 */   static String[][] mapArray = new String[20][16];
/*  37:    */   static Thread loop2;
/*  38:    */   static int exp;
/*  39: 54 */   static int herohp = 30;
/*  40: 55 */   static int heromp = 30;
/*  41: 56 */   static int heroxp = 0;
/*  42: 57 */   static int heroLevel = 1;
/*  43: 58 */   static int heroAtt = 5;
/*  44: 59 */   static int enemyAtt = 2;
/*  45: 60 */   static int heroDef = 4;
/*  46: 61 */   static int enemyDef = 2;
/*  47: 62 */   static int enemyhp = 10;
/*  48: 63 */   static int enemymp = 10;
/*  49:    */   static int enemyhp2;
/*  50: 65 */   static int herohp2 = herohp;
/*  51: 66 */   static Random ran = new Random();
/*  52:    */   static Thread loop;
/*  53: 68 */   static int enemyPer = 100;
/*  54: 69 */   static int heroPer = 100;
/*  55:    */   
/*  56:    */   public static void main(String[] args)
/*  57:    */     throws Exception
/*  58:    */   {
/*  59: 73 */     titleScreen();
/*  60: 74 */     drawMap(mapNameImage);
/*  61: 75 */     storeMap(mapNameText);
/*  62: 76 */     drawCharacter(x2, y2, direction);
/*  63: 77 */     Runnable r1 = new Runnable()
/*  64:    */     {
/*  65:    */       public void run()
/*  66:    */       {
/*  67:    */         for (;;)
/*  68:    */         {
/*  69: 80 */           BasicGridSystem.x1 = BasicGridSystem.x2;
/*  70: 81 */           BasicGridSystem.y1 = BasicGridSystem.y2;
/*  71: 82 */           BasicGridSystem.ch = BasicGridSystem.c.getKey();
/*  72: 83 */           BasicGridSystem.ch = Character.toLowerCase(BasicGridSystem.ch);
/*  73: 84 */           if (BasicGridSystem.herohp2 <= 0) {
/*  74:    */             try
/*  75:    */             {
/*  76: 88 */               BasicGridSystem.gameOver();
/*  77:    */             }
/*  78:    */             catch (Exception localException) {}
/*  79:    */           }
/*  80: 92 */           switch (BasicGridSystem.ch)
/*  81:    */           {
/*  82:    */           case 'w': 
/*  83: 94 */             BasicGridSystem.currentMapPosition(BasicGridSystem.x1, BasicGridSystem.y1);
/*  84: 95 */             BasicGridSystem.y1 -= 32;
/*  85: 96 */             BasicGridSystem.direction = "n";
/*  86:    */             
/*  87:    */ 
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:    */ 
/*  92:    */ 
/*  93:104 */             break;
/*  94:    */           case 'a': 
/*  95:106 */             BasicGridSystem.currentMapPosition(BasicGridSystem.x1, BasicGridSystem.y1);
/*  96:107 */             BasicGridSystem.x1 -= 32;
/*  97:108 */             BasicGridSystem.direction = "w";
/*  98:    */             
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:    */ 
/* 104:    */ 
/* 105:116 */             break;
/* 106:    */           case 's': 
/* 107:118 */             BasicGridSystem.currentMapPosition(BasicGridSystem.x1, BasicGridSystem.y1);
/* 108:119 */             BasicGridSystem.y1 += 32;
/* 109:120 */             BasicGridSystem.direction = "s";
/* 110:    */             
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:128 */             break;
/* 118:    */           case 'd': 
/* 119:130 */             BasicGridSystem.currentMapPosition(BasicGridSystem.x1, BasicGridSystem.y1);
/* 120:131 */             BasicGridSystem.x1 += 32;
/* 121:132 */             BasicGridSystem.direction = "e";
/* 122:    */             
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:140 */             break;
/* 130:    */           case 'i': 
/* 131:    */             try
/* 132:    */             {
/* 133:143 */               BasicGridSystem.inventory();
/* 134:    */             }
/* 135:    */             catch (IOException localIOException1) {}
/* 136:    */           case 'h': 
/* 137:150 */             BasicGridSystem.herohp2 = BasicGridSystem.herohp;
/* 138:151 */             BasicGridSystem.heroPer = 100;
/* 139:152 */             break;
/* 140:    */           case 'b': 
/* 141:154 */             BasicGridSystem.heroAtt = 100;
/* 142:155 */             break;
/* 143:    */           }
/* 144:190 */           if ((BasicGridSystem.ch == 'w') || (BasicGridSystem.ch == 'a') || (BasicGridSystem.ch == 's') || (BasicGridSystem.ch == 'd')) {
/* 145:    */             try
/* 146:    */             {
/* 147:194 */               BasicGridSystem.randomEncounter(BasicGridSystem.ch);
/* 148:    */             }
/* 149:    */             catch (Exception localException1) {}
/* 150:    */           }
/* 151:201 */           if (BasicGridSystem.x1 == -32) {
/* 152:202 */             BasicGridSystem.x1 = 608;
/* 153:    */           }
/* 154:204 */           if (BasicGridSystem.y1 == -32) {
/* 155:205 */             BasicGridSystem.y1 = 480;
/* 156:    */           }
/* 157:207 */           if (BasicGridSystem.x1 == 640) {
/* 158:208 */             BasicGridSystem.x1 = 0;
/* 159:    */           }
/* 160:210 */           if (BasicGridSystem.y1 == 512) {
/* 161:211 */             BasicGridSystem.y1 = 0;
/* 162:    */           }
/* 163:214 */           if (BasicGridSystem.ch != 0) {
/* 164:    */             try
/* 165:    */             {
/* 166:216 */               BasicGridSystem.drawLastPos(BasicGridSystem.x2, BasicGridSystem.y2);
/* 167:217 */               BasicGridSystem.drawCharacter(BasicGridSystem.x1, BasicGridSystem.y1, BasicGridSystem.direction);
/* 168:218 */               BasicGridSystem.x2 = BasicGridSystem.x1;
/* 169:219 */               BasicGridSystem.y2 = BasicGridSystem.y1;
/* 170:    */             }
/* 171:    */             catch (IOException ex)
/* 172:    */             {
/* 173:221 */               System.out.println("Error");
/* 174:    */             }
/* 175:    */           }
/* 176:224 */           BasicGridSystem.ch = '\000';
/* 177:    */         }
/* 178:    */       }
/* 179:230 */     };
/* 180:231 */     loop = new Thread(r1, "Game Input");
/* 181:232 */     loop.start();
/* 182:    */   }
/* 183:    */   
/* 184:    */   public static void animationRandomEncounter()
/* 185:    */     throws Exception
/* 186:    */   {
/* 187:238 */     int x = 0;
/* 188:239 */     int y = 0;
/* 189:240 */     while (x < c.getWidth())
/* 190:    */     {
/* 191:242 */       c.fillRect(x, y, 64, 64);
/* 192:243 */       Thread.sleep(20L);
/* 193:244 */       y += 64;
/* 194:245 */       if (y >= c.getHeight())
/* 195:    */       {
/* 196:247 */         x += 64;
/* 197:248 */         y = 0;
/* 198:    */       }
/* 199:    */     }
/* 200:    */   }
/* 201:    */   
/* 202:    */   public static void attack(int heroAttack, int enemyAttack)
/* 203:    */   {
/* 204:254 */     int dmg = ran.nextInt(heroAttack);
/* 205:255 */     c.setColor(Color.white);
/* 206:256 */     c.fillRect(500, 0, 140, 50);
/* 207:257 */     c.setColor(Color.black);
/* 208:258 */     c.drawString("Hero did: " + dmg + " points of damage!", 499, 45);
/* 209:259 */     enemyhp2 -= dmg;
/* 210:260 */     enemyPer = enemyhp2 * 100 / enemyhp;
/* 211:261 */     displayEnemyHP();
/* 212:262 */     enemyAttack(enemyAttack);
/* 213:    */   }
/* 214:    */   
/* 215:    */   public static void currentMapPosition(int x, int y)
/* 216:    */   {
/* 217:277 */     u = x / 32;
/* 218:278 */     v = y / 32;
/* 219:    */   }
/* 220:    */   
/* 221:    */   public static void displayHP()
/* 222:    */   {
/* 223:282 */     c.drawRoundRect(99, 299, 101, 12, 2, 2);
/* 224:283 */     if (heroPer > 49) {
/* 225:284 */       c.setColor(Color.green);
/* 226:285 */     } else if (heroPer > 19) {
/* 227:286 */       c.setColor(Color.yellow);
/* 228:    */     } else {
/* 229:288 */       c.setColor(Color.red);
/* 230:    */     }
/* 231:289 */     c.fillRoundRect(100, 300, heroPer, 11, 2, 2);
/* 232:290 */     c.setColor(Color.black);
/* 233:    */   }
/* 234:    */   
/* 235:    */   public static void displayEnemyHP()
/* 236:    */   {
/* 237:294 */     c.drawRoundRect(499, 3, 101, 12, 2, 2);
/* 238:295 */     if (enemyPer > 49) {
/* 239:296 */       c.setColor(Color.green);
/* 240:297 */     } else if (enemyPer > 19) {
/* 241:298 */       c.setColor(Color.yellow);
/* 242:    */     } else {
/* 243:300 */       c.setColor(Color.red);
/* 244:    */     }
/* 245:301 */     c.fillRoundRect(500, 4, enemyPer, 11, 2, 2);
/* 246:302 */     c.setColor(Color.black);
/* 247:    */   }
/* 248:    */   
/* 249:    */   public static void drawCharacter(int x, int y, String direction)
/* 250:    */     throws IOException
/* 251:    */   {
/* 252:307 */     InputStream inputstream = BasicGridSystem.class
/* 253:308 */       .getResourceAsStream("/game1/Player Sprite ".concat(direction)
/* 254:309 */       .concat(".png"));
/* 255:310 */     Image sprite = SpriteImport.makeColorTransparent(inputstream, 
/* 256:311 */       Color.white);
/* 257:312 */     c.drawImage(sprite, x, y, null);
/* 258:313 */     inputstream.close();
/* 259:    */   }
/* 260:    */   
/* 261:    */   public static void drawLastPos(int x, int y)
/* 262:    */     throws IOException
/* 263:    */   {
/* 264:317 */     terrain(mapArray[u][v]);
/* 265:318 */     c.drawImage(tile, x, y, null);
/* 266:    */   }
/* 267:    */   
/* 268:    */   public static void drawMap()
/* 269:    */     throws IOException
/* 270:    */   {
/* 271:322 */     int width = c.getWidth();
/* 272:323 */     int height = c.getHeight();
/* 273:324 */     int x = 0;
/* 274:325 */     int y = 0;
/* 275:326 */     double grid = 0.0D;
/* 276:327 */     while (grid < width)
/* 277:    */     {
/* 278:328 */       while (x < width)
/* 279:    */       {
/* 280:329 */         c.drawImage(tile, x, y, null);
/* 281:330 */         x += 32;
/* 282:    */       }
/* 283:332 */       x = 0;
/* 284:333 */       y += 32;
/* 285:334 */       grid += width / 18;
/* 286:    */     }
/* 287:    */   }
/* 288:    */   
/* 289:    */   public static void drawMap(String mapName)
/* 290:    */     throws IOException
/* 291:    */   {
/* 292:345 */     int x = 0;
/* 293:346 */     int y = 0;
/* 294:347 */     int j = 0;
/* 295:    */     
/* 296:349 */     String line = "";
/* 297:352 */     if (mapName.endsWith(".txt"))
/* 298:    */     {
/* 299:353 */       InputStream inputstream = BasicGridSystem.class
/* 300:354 */         .getResourceAsStream(mapName);
/* 301:355 */       BufferedReader reader = new BufferedReader(new InputStreamReader(
/* 302:356 */         inputstream));
/* 303:357 */       line = reader.readLine();
/* 304:358 */       while (line != null)
/* 305:    */       {
/* 306:359 */         int i = 0;
/* 307:360 */         StringTokenizer token = new StringTokenizer(line);
/* 308:362 */         while (token.hasMoreTokens())
/* 309:    */         {
/* 310:363 */           String tileType = token.nextToken();
/* 311:364 */           mapArray[i][j] = tileType;
/* 312:365 */           if (tileType.equals("g")) {
/* 313:366 */             terrain("g");
/* 314:367 */           } else if (tileType.equals("s")) {
/* 315:368 */             terrain("s");
/* 316:    */           }
/* 317:370 */           c.drawImage(tile, x, y, null);
/* 318:371 */           x += 32;
/* 319:372 */           i++;
/* 320:    */         }
/* 321:374 */         y += 32;
/* 322:375 */         x = 0;
/* 323:376 */         j++;
/* 324:377 */         line = reader.readLine();
/* 325:    */       }
/* 326:379 */       inputstream.close();
/* 327:    */     }
/* 328:380 */     else if ((mapName.endsWith(".jpg") | mapName.endsWith(".png")))
/* 329:    */     {
/* 330:381 */       InputStream inputstream = BasicGridSystem.class
/* 331:382 */         .getResourceAsStream(mapName);
/* 332:383 */       map = ImageIO.read(inputstream);
/* 333:384 */       c.drawImage(map, 0, 0, null);
/* 334:    */       
/* 335:386 */       inputstream.close();
/* 336:    */     }
/* 337:    */     else
/* 338:    */     {
/* 339:388 */       new ErrorMessage("Error when loading map");
/* 340:    */     }
/* 341:    */   }
/* 342:    */   
/* 343:    */   public static void enemyAttack(int enemyAttack)
/* 344:    */   {
/* 345:398 */     if (enemyAttack <= 1) {
/* 346:399 */       enemyAttack = 2;
/* 347:    */     }
/* 348:400 */     int dmg = ran.nextInt(enemyAttack);
/* 349:401 */     c.setColor(Color.white);
/* 350:402 */     c.fillRect(100, 200, 140, 150);
/* 351:403 */     c.setColor(Color.black);
/* 352:404 */     c.drawString("Enemy did: " + dmg + " points of damage!", 100, 265);
/* 353:405 */     herohp2 -= dmg;
/* 354:406 */     heroPer = herohp2 * 100 / herohp;
/* 355:407 */     displayHP();
/* 356:    */   }
/* 357:    */   
/* 358:    */   public static void escape(int enemyLevel)
/* 359:    */     throws Exception
/* 360:    */   {
/* 361:412 */     if (heroLevel > enemyLevel)
/* 362:    */     {
/* 363:414 */       drawMap(mapNameImage);
/* 364:415 */       drawCharacter(x1, y1, direction);
/* 365:416 */       loop.start();
/* 366:    */     }
/* 367:418 */     else if (heroLevel <= enemyLevel)
/* 368:    */     {
/* 369:420 */       Random ran = new Random();
/* 370:421 */       int chance = ran.nextInt(3) + 1;
/* 371:422 */       if (chance == 1)
/* 372:    */       {
/* 373:424 */         drawMap(mapNameImage);
/* 374:425 */         drawCharacter(x1, y1, direction);
/* 375:426 */         loop.start();
/* 376:    */       }
/* 377:    */       else
/* 378:    */       {
/* 379:430 */         c.drawString("Escape attempt failed.", 275, 160);
/* 380:431 */         Thread.sleep(1000L);
/* 381:432 */         c.setColor(Color.white);
/* 382:433 */         c.fillRect(275, 160, 110, 15);
/* 383:434 */         c.setColor(Color.black);
/* 384:    */       }
/* 385:    */     }
/* 386:    */   }
/* 387:    */   
/* 388:    */   public static void gameOver()
/* 389:    */     throws Exception
/* 390:    */   {
/* 391:441 */     c.clear();
/* 392:442 */     for (int i = 0; i < 50; i++) {
/* 393:443 */       c.println("GAME OVER");
/* 394:    */     }
/* 395:444 */     Thread.sleep(3000L);
/* 396:445 */     System.exit(0);
/* 397:    */   }
/* 398:    */   
/* 399:    */   public static void inventory()
/* 400:    */     throws IOException
/* 401:    */   {
/* 402:449 */     String armour = null;
/* 403:450 */     String[] armourarray = new String[6];
/* 404:    */     
/* 405:452 */     InputStream inputstream = BasicGridSystem.class
/* 406:453 */       .getResourceAsStream("/game1/lib/SaveData");
/* 407:454 */     BufferedReader reader = new BufferedReader(new InputStreamReader(
/* 408:455 */       inputstream));
/* 409:    */     
/* 410:457 */     c.clear();
/* 411:458 */     String line = reader.readLine();
/* 412:459 */     for (int i = 0; i < 6; i++)
/* 413:    */     {
/* 414:460 */       StringTokenizer token = new StringTokenizer(line);
/* 415:461 */       while (token.hasMoreTokens()) {
/* 416:462 */         armour = token.nextToken();
/* 417:    */       }
/* 418:464 */       line = reader.readLine();
/* 419:465 */       armourarray[i] = armour;
/* 420:466 */       c.println(armourarray[i]);
/* 421:    */     }
/* 422:    */     do
/* 423:    */     {
/* 424:475 */       ch = c.getKey();
/* 425:476 */     } while (ch != 'i');
/* 426:482 */     inputstream.close();
/* 427:483 */     drawMap(mapNameImage);
/* 428:    */   }
/* 429:    */   
/* 430:    */   public static void levelUp()
/* 431:    */   {
/* 432:488 */     heroLevel += 1;
/* 433:489 */     heroAtt += 1;
/* 434:490 */     heroDef += 1;
/* 435:491 */     herohp += 10;
/* 436:    */     
/* 437:493 */     herohp2 = herohp;
/* 438:494 */     heroPer = 100;
/* 439:495 */     c.clear();
/* 440:496 */     c.drawString("Level Up! You are now level: " + heroLevel, 250, 245);
/* 441:497 */     c.getChar();
/* 442:    */   }
/* 443:    */   
/* 444:    */   public static void randomEncounter(char pos)
/* 445:    */     throws Exception
/* 446:    */   {
/* 447:501 */     int num = ran.nextInt(20);
/* 448:502 */     if (num == 15)
/* 449:    */     {
/* 450:504 */       if (pos == 'w') {
/* 451:506 */         y1 += 32;
/* 452:508 */       } else if (pos == 'a') {
/* 453:510 */         x1 += 32;
/* 454:512 */       } else if (pos == 's') {
/* 455:514 */         y1 -= 32;
/* 456:516 */       } else if (pos == 'd') {
/* 457:518 */         x1 -= 32;
/* 458:    */       }
/* 459:520 */       animationRandomEncounter();
/* 460:521 */       startBattle();
/* 461:    */     }
/* 462:    */   }
/* 463:    */   
/* 464:    */   public static void spellMenu() {}
/* 465:    */   
/* 466:    */   public static void startBattle()
/* 467:    */     throws Exception
/* 468:    */   {
/* 469:539 */     Thread.sleep(1000L);
/* 470:540 */     String monster = null;
/* 471:541 */     int choice = 1;
/* 472:542 */     int num = ran.nextInt(2);
/* 473:543 */     int level = 1;
/* 474:544 */     int heroAttack = heroAtt - enemyDef;
/* 475:545 */     int enemyAttack = enemyAtt - heroDef;
/* 476:546 */     if (num == 1)
/* 477:    */     {
/* 478:548 */       level = ran.nextInt(15) + 1;
/* 479:549 */       monster = "Rabid Dog";
/* 480:    */     }
/* 481:551 */     else if (num == 0)
/* 482:    */     {
/* 483:553 */       level = ran.nextInt(15) + 1;
/* 484:554 */       monster = "Rat";
/* 485:    */     }
/* 486:556 */     if ((level == 12) || (level == 13) || (level == 14))
/* 487:    */     {
/* 488:558 */       enemyhp = 20;
/* 489:559 */       level = 2;
/* 490:    */     }
/* 491:561 */     if (level == 15)
/* 492:    */     {
/* 493:563 */       enemyhp = 30;
/* 494:564 */       level = 3;
/* 495:    */     }
/* 496:    */     else
/* 497:    */     {
/* 498:568 */       enemyhp = 10;
/* 499:569 */       level = 1;
/* 500:    */     }
/* 501:571 */     enemyhp2 = enemyhp;
/* 502:572 */     if (heroAttack < 2) {
/* 503:573 */       heroAttack = 2;
/* 504:    */     }
/* 505:574 */     c.clear();
/* 506:575 */     c.drawString("A Wild " + monster + " Appeared!", 250, 245);
/* 507:576 */     Thread.sleep(3000L);
/* 508:577 */     c.clear();
/* 509:578 */     c.drawLine(0, 350, 640, 350);
/* 510:579 */     c.drawLine(240, 350, 240, 500);
/* 511:580 */     c.drawRect(70, 375, 60, 22);
/* 512:581 */     c.drawString("ATTACK", 75, 390);
/* 513:582 */     c.drawString("SPELL", 75, 430);
/* 514:583 */     c.drawString("RUN", 75, 470);
/* 515:584 */     c.drawString("Level: " + level, 499, 30);
/* 516:    */     
/* 517:586 */     displayHP();
/* 518:587 */     displayEnemyHP();
/* 519:    */     for (;;)
/* 520:    */     {
/* 521:590 */       if (enemyhp2 <= 0)
/* 522:    */       {
/* 523:592 */         c.drawString("You defeated the Wild " + monster + "!", 250, 160);
/* 524:593 */         Thread.sleep(5000L);
/* 525:594 */         xpGain();
/* 526:595 */         break;
/* 527:    */       }
/* 528:597 */       ch2 = c.getKey();
/* 529:598 */       switch (ch2)
/* 530:    */       {
/* 531:    */       case 'w': 
/* 532:601 */         choice--;
/* 533:602 */         if (choice == 0) {
/* 534:603 */           choice = 1;
/* 535:    */         }
/* 536:604 */         c.setColor(Color.white);
/* 537:605 */         c.drawRect(70, 415, 60, 22);
/* 538:606 */         c.drawRect(70, 455, 60, 22);
/* 539:607 */         c.setColor(Color.black);
/* 540:608 */         if (choice == 2) {
/* 541:610 */           c.drawRect(70, 415, 60, 22);
/* 542:612 */         } else if (choice == 1) {
/* 543:614 */           c.drawRect(70, 375, 60, 22);
/* 544:    */         }
/* 545:616 */         break;
/* 546:    */       case 's': 
/* 547:618 */         choice++;
/* 548:619 */         if (choice == 4) {
/* 549:620 */           choice = 3;
/* 550:    */         }
/* 551:621 */         if (choice == 2)
/* 552:    */         {
/* 553:623 */           c.setColor(Color.white);
/* 554:624 */           c.drawRect(70, 375, 60, 22);
/* 555:625 */           c.drawRect(70, 455, 60, 22);
/* 556:626 */           c.setColor(Color.black);
/* 557:627 */           c.drawRect(70, 415, 60, 22);
/* 558:    */         }
/* 559:629 */         else if (choice == 3)
/* 560:    */         {
/* 561:631 */           c.setColor(Color.white);
/* 562:632 */           c.drawRect(70, 415, 60, 22);
/* 563:633 */           c.setColor(Color.black);
/* 564:634 */           c.drawRect(70, 455, 60, 22);
/* 565:    */         }
/* 566:637 */         break;
/* 567:    */       case ' ': 
/* 568:639 */         if (choice == 1) {
/* 569:641 */           attack(heroAttack, enemyAttack);
/* 570:    */         }
/* 571:643 */         if (choice == 2) {
/* 572:645 */           spellMenu();
/* 573:    */         }
/* 574:647 */         if (choice == 3) {
/* 575:649 */           escape(level);
/* 576:    */         }
/* 577:    */         break;
/* 578:    */       }
/* 579:    */     }
/* 580:653 */     enemyPer = 100;
/* 581:    */     
/* 582:655 */     drawMap(mapNameImage);
/* 583:656 */     drawCharacter(x1, y1, direction);
/* 584:    */   }
/* 585:    */   
/* 586:    */   public static void storeMap(String mapName)
/* 587:    */     throws IOException
/* 588:    */   {
/* 589:662 */     String line = "";
/* 590:    */     
/* 591:664 */     int j = 0;
/* 592:    */     
/* 593:666 */     InputStream inputstream = BasicGridSystem.class
/* 594:667 */       .getResourceAsStream(mapName);
/* 595:668 */     BufferedReader reader = new BufferedReader(new InputStreamReader(
/* 596:669 */       inputstream));
/* 597:670 */     line = reader.readLine();
/* 598:671 */     while (line != null)
/* 599:    */     {
/* 600:672 */       int i = 0;
/* 601:673 */       StringTokenizer token = new StringTokenizer(line);
/* 602:675 */       while (token.hasMoreTokens())
/* 603:    */       {
/* 604:676 */         String tileType = token.nextToken();
/* 605:677 */         mapArray[i][j] = tileType;
/* 606:678 */         i++;
/* 607:    */       }
/* 608:680 */       j++;
/* 609:681 */       line = reader.readLine();
/* 610:    */     }
/* 611:683 */     inputstream.close();
/* 612:    */   }
/* 613:    */   
/* 614:    */   public static void terrain(String type)
/* 615:    */     throws IOException
/* 616:    */   {
/* 617:687 */     if (type.equalsIgnoreCase("g"))
/* 618:    */     {
/* 619:688 */       InputStream inputstream = BasicGridSystem.class
/* 620:689 */         .getResourceAsStream("/game1/Grass2.jpg");
/* 621:690 */       tile = ImageIO.read(inputstream);
/* 622:691 */       inputstream.close();
/* 623:    */     }
/* 624:693 */     if (type.equalsIgnoreCase("s"))
/* 625:    */     {
/* 626:694 */       InputStream inputstream = BasicGridSystem.class
/* 627:695 */         .getResourceAsStream("/game1/Stone.jpg");
/* 628:696 */       tile = ImageIO.read(inputstream);
/* 629:697 */       inputstream.close();
/* 630:    */     }
/* 631:    */   }
/* 632:    */   
/* 633:    */   public static void titleScreen()
/* 634:    */   {
/* 635:706 */     c.drawString("TITLE", 305, 100);
/* 636:707 */     c.drawString("NEW GAME", 289, 250);
/* 637:708 */     c.drawString("EXIT", 309, 350);
/* 638:709 */     c.drawRect(286, 235, 72, 20);
/* 639:    */     int choice;
/* 640:    */     do
/* 641:    */     {
/* 642:716 */       choice = 1;
/* 643:717 */       ch = c.getKey();
/* 644:718 */       switch (ch)
/* 645:    */       {
/* 646:    */       case 'w': 
/* 647:721 */         choice--;
/* 648:722 */         if (choice == 0) {
/* 649:724 */           choice = 1;
/* 650:    */         }
/* 651:726 */         c.setColor(Color.white);
/* 652:727 */         c.drawRect(306, 335, 32, 20);
/* 653:728 */         c.setColor(Color.black);
/* 654:729 */         c.drawRect(286, 235, 72, 20);
/* 655:730 */         break;
/* 656:    */       case 's': 
/* 657:732 */         choice++;
/* 658:733 */         if (choice == 3) {
/* 659:735 */           choice = 2;
/* 660:    */         }
/* 661:737 */         c.setColor(Color.white);
/* 662:738 */         c.drawRect(286, 235, 72, 20);
/* 663:739 */         c.setColor(Color.black);
/* 664:740 */         c.drawRect(306, 335, 32, 20);
/* 665:741 */         break;
/* 666:    */       case ' ': 
/* 667:743 */         if (choice == 1) {
/* 668:745 */           choice = 4;
/* 669:748 */         } else if (choice == 2) {
/* 670:750 */           System.exit(0);
/* 671:    */         }
/* 672:    */         break;
/* 673:    */       }
/* 674:765 */     } while (choice != 4);
/* 675:    */   }
/* 676:    */   
/* 677:    */   public static void xpGain()
/* 678:    */   {
/* 679:774 */     heroxp += 10;
/* 680:775 */     if (heroxp >= 100) {
/* 681:776 */       levelUp();
/* 682:    */     }
/* 683:    */   }
/* 684:    */   
/* 685:    */   public static void xpGain(int gain)
/* 686:    */   {
/* 687:780 */     heroxp += gain;
/* 688:781 */     if (heroxp >= 100) {
/* 689:782 */       levelUp();
/* 690:    */     }
/* 691:    */   }
/* 692:    */ }


/* Location:           C:\Users\Sergei Ten\workspace\game1\src\
 * Qualified Name:     game1.BasicGridSystem
 * JD-Core Version:    0.7.0.1
 */
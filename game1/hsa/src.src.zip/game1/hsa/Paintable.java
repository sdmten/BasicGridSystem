package game1.hsa;

import java.awt.Graphics;

public abstract class Paintable
{
  public abstract void paint(Graphics paramGraphics);
}


/* Location:           C:\Users\Sergei Ten\workspace\game1\src\
 * Qualified Name:     game1.hsa.Paintable
 * JD-Core Version:    0.7.0.1
 */
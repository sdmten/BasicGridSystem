package game1.hsa;

import java.awt.Graphics;

abstract interface DrawGraphics
{
  public abstract void drawWindowToGraphics(Graphics paramGraphics);
  
  public abstract void drawWindowToGraphics(Graphics paramGraphics, int paramInt1, int paramInt2);
  
  public abstract int getMargin();
}


/* Location:           C:\Users\Sergei Ten\workspace\game1\src\
 * Qualified Name:     game1.hsa.DrawGraphics
 * JD-Core Version:    0.7.0.1
 */
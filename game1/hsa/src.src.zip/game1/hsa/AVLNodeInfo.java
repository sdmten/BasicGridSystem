/*   1:    */ package game1.hsa;
/*   2:    */ 
/*   3:    */ class AVLNodeInfo
/*   4:    */ {
/*   5:    */   public AVLTreeNode node;
/*   6:    */   public int stateChange;
/*   7:    */   
/*   8:    */   public AVLNodeInfo(AVLTreeNode node, int stateChange)
/*   9:    */   {
/*  10:752 */     this.node = node;
/*  11:753 */     this.stateChange = stateChange;
/*  12:    */   }
/*  13:    */ }


/* Location:           C:\Users\Sergei Ten\workspace\game1\src\
 * Qualified Name:     game1.hsa.AVLNodeInfo
 * JD-Core Version:    0.7.0.1
 */